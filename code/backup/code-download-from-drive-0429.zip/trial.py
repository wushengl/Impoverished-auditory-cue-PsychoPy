#from psychopy import prefs
#prefs.hardware['audioLib'] = ['PTB'] 

from psychopy import visual, event #, sound, parallel, core
#import psychtoolbox as ptb
import numpy as np 
import random
import time
import pdb

import serial
import medussa


# press 'r' to repeat or click on button?
# https://discourse.psychopy.org/t/how-to-play-and-repeat-stimuli-after-manual-click/4845

#parallel.setPortAddress(0x378)  # address for parallel port on many machines
#pinNumber = 2  # choose a pin to write to (2-9).

# int and bytes
# zzz = 253
# zzz.to_bytes(1,'little')
# int.from_bytes(zzz.to_bytes(1,'little'),'little')


def runTrial(win,trialCond,ti,total,corrCount,isTrain=True): 
    
    spaCond = trialCond['spaCond']
    tarDir = trialCond['tarDir']
    intCond = trialCond['intCond'] # this is None for training trial
    
    trialInfo = generateTrial(trialCond) 
    playTrial(win,trialInfo)
    response = collectResponse(win,ti,total) 
    trialInfo['response'] = response
    
    if isTrain: 
        results, corrCount = feedbackScreen(win,trialInfo,corrCount,total)
    else:
        results = getResult(trialInfo)
        if np.sum(results) == 3:
            corrCount += 1
    
    trialInfo['results'] = results
    
    return trialInfo, corrCount


def getResult(trialInfo):
    
    targets = np.array(trialInfo['targets']) 
    syllables = np.array(['ba','da','ga']) 
    resp = trialInfo['response']
    responses = syllables[resp]
    
    results = (responses == targets).astype(int)
    
    return results


def feedbackScreen(win,trialInfo,corrCount,total):
    
    targets = np.array(trialInfo['targets']) 
    results = getResult(trialInfo)
    
    if np.sum(results) == 3:
        trialPass = 'have passed'
        corrCount += 1
    else:
        trialPass = 'didn\'t pass'
    
    feedback = 'The correct answer is ' + targets[0] + ', ' + targets[1] + ', ' + targets[2] + '.\n'\
            'You ' + trialPass + ' this trial. \n'\
            'Press Space to move on.'
    txt = visual.TextStim(win,text=feedback)
    
    corrTxt = 'Current training score: ' + str(corrCount) + '/' + str(total)
    txt_corr = visual.TextStim(win,text=corrTxt,pos=[0,-0.5])
    
    txt.draw()
    txt_corr.draw()
    win.flip()
    
    event.waitKeys(keyList=['space'])
    
    return results, corrCount


def collectResponse(win,ti,total):
    
    crtTrial = 'Current Trial: ' + str(ti) + '/' + str(total)
    txt_trial = visual.TextStim(win,text=crtTrial,pos=[0.65,-0.8],height=0.08)
    
    inst = 'Click on the syllables you heard from the target direction, press Space to move on.'
    txt = visual.TextStim(win,text=inst,pos=[0,0.6])
    
    s1 = '1st Syllable: '
    s2 = '1st Syllable: '
    s3 = '1st Syllable: '
    txt_s1 = visual.TextStim(win,text=s1,pos=[-0.6,0.2],height=0.08)
    txt_s2 = visual.TextStim(win,text=s2,pos=[-0.6,-0.05],height=0.08)
    txt_s3 = visual.TextStim(win,text=s3,pos=[-0.6,-0.3],height=0.08)
    
    scaleSetting = {
        'win': win,
        'low': 0,
        'high': 2,
        'labels': ['ba','da','ga'],
        'marker': 'circle',
        'lineColor': 'grey',
        'scale': None,
        'mouseOnly': True,
        'showAccept': False,
        'singleClick': True
    } # 'acceptKeys': 'space'
    sylbScale1 = visual.RatingScale(pos=[0,0.25], **scaleSetting)
    sylbScale2 = visual.RatingScale(pos=[0,0], **scaleSetting)
    sylbScale3 = visual.RatingScale(pos=[0,-0.25], **scaleSetting)
    
    txt_trial.draw()
    txt.draw()
    txt_s1.draw()
    txt_s2.draw()
    txt_s3.draw()
    sylbScale1.draw()
    sylbScale2.draw()
    sylbScale3.draw()
    
    win.flip()
    
    while sylbScale1.noResponse or sylbScale2.noResponse or sylbScale3.noResponse or ('space' not in event.getKeys(keyList=['space'])):
        txt_trial.draw()
        txt.draw()
        txt_s1.draw()
        txt_s2.draw()
        txt_s3.draw()
        sylbScale1.draw()
        sylbScale2.draw()
        sylbScale3.draw()
        win.flip()
    
    res1 = sylbScale1.getRating()
    res2 = sylbScale2.getRating()
    res3 = sylbScale3.getRating()
    
    response = [res1,res2,res3]
    
    return response

def getTriggerCode(spaCond,intCond,tarDir):
    spaCond_pool = ['HRTF','ITD','ILD']
    intCond_pool = [None,'cont','ips'] # TODO: what do we want?
    tarDir_pool = ['30L','30R']

    code = spaCond_pool.index(spaCond)*len(intCond_pool)*len(tarDir_pool) + intCond_pool.index(intCond)*len(tarDir_pool) + tarDir_pool.index(tarDir)

    return code+1


def generateTrial(trialCond):
    '''
    This function is used for generating one trial with given conditions:
        - HRTF/ILD/ITD
        - interrupted/not interrupted
        - target left/right
    Input:
        - tarDir: target direction in string, e.g. '30L'
        - intCond: interrupter condition, could be None or 'meow'
    Return:
        - trialInfo: e.g. {'tarDir': '30L', 
            'intCond' = 'meow', 
            'targets': ['ba','da','ga'], 
            'distractors': ['da','da','ga'], 
            'stream': ['ba','da','meow','da','da','ga','ga']}

        * by saving targets and distractors in short version can make it easier for later analysis, making stream full name and 
        in the right order can make it easier for playing the stimuli
    '''
    
    spaCond = trialCond['spaCond']
    tarDir = trialCond['tarDir']
    intCond = trialCond['intCond']
    
    Ts = randomStream()
    Ds = randomStream()
    
    if intCond:
        intSti = 'meow'
    else:
        intSti = None
    
    stream = [Ts[0],Ds[0],intSti,Ts[1],Ds[1],Ts[2],Ds[2]]
    stream = [stimulus for stimulus in stream if stimulus] # if interupter is None, remove it

    trig = getTriggerCode(spaCond,intCond,tarDir)
    
    trialStim = {
        'spaCond': spaCond,
        'tarDir': tarDir,
        'intCond': intCond,
        'targets': Ts,
        'distractors': Ds,
        'stream': stream,
        'trigger': trig
    }
    
    return trialStim

def playTrial(win,trialStim):
    
    spaCond = trialStim['spaCond']
    tarDir = trialStim['tarDir']
    intCond = trialStim['intCond']
    stream = trialStim['stream']
    trig = trialStim['trigger']
    
    # time list 
    if len(stream) == 6:
        timeList = np.array([1.0, 1.3, 1.6, 1.9, 2.2, 2.5]) + 0.5
        codes = ['T','D','T','D','T','D']
    elif len(stream) == 7:
        timeList = np.array([1.0, 1.3, 1.475, 1.6, 1.9, 2.2, 2.5]) + 0.5
        codes = ['T','D','I','T','D','T','D']
    else:
        print('stream length not right')
        raise ValueError
    
    # stimulus
    '''
    # TODO: 
    do we want to add them up first to present them one by one?
    1. read install.md for medussa
    2. read usage example
    3. read source code for play_array if it's python
    '''
    #cue = sound.Sound(fillStimNames('ba',spaCond,tarDir,'T',intCond),stereo=True) 
    cue,fs = medussa.read_file(fillStimNames('ba',spaCond,tarDir,'T',intCond)) # TODO
    
    
    stimuli = []
    for i in range(len(stream)):
        stimuli.append(medussa.read_file(fillStimNames(stream[i],spaCond,tarDir,codes[i],intCond))[0]) # TODO
        # opened as an object, need to transfer to numpy array
        # Do we open then play or play_file? any difference?
        # well, open first we can add them to stream so more flexible

        #stimuli.append(sound.Sound(fillStimNames(stream[i],spaCond,tarDir,codes[i],intCond),stereo=True)) 
    
    cross = visual.TextStim(win=win,text='+',height=0.3)
    cross.draw() 
    #win.callOnFlip(port.write,trig.to_bytes(1,'little')) # TODO: check if this is working right in lab
    win.flip() 

    
    time.sleep(0.5)
    audio_code = 99
    #port.write(audio_code.to_bytes(1,'little'))

    medussa.play_array(cue,fs, output_device_id=16) # TODO

    #time_trial = []
    for i in range(len(stream)):
        # TODO: do we want to add them up or play them one by one? Can medussa deal with it if playing one-by-one?
        #stimuli[i].play(when=now+timeList[i])
        #time_trial.append(timer.getTime())
        medussa.play_array(stimuli[i],fs, output_device_id=16)
        time.sleep(timeList[i])
    # while true if isplaying sleep

    time.sleep(0.5) # TODO: do we need to sleep if using medussa?


def randomStream():
    '''
    This function is used for generating one random stream, each syllable could be ba/da/ga with replacement.
    '''
    sylbOptions = ['ba','da','ga']
    stream = [sylbOptions[random.randint(0,2)],sylbOptions[random.randint(0,2)],sylbOptions[random.randint(0,2)]]
    
    return stream


def fillStimNames(sylb,spaCond,tarDir,codei,intDir):
    sylbDir = getSylbDir(tarDir,codei,intDir)
    if codei == 'I':
        file_name = '../stimuli/' + sylb + '_' + sylbDir + '_' + spaCond + '_5dB.wav' 
    else:
        file_name = '../stimuli/' + sylb + '_' + sylbDir + '_' + spaCond + '.wav'
    return file_name


def getSylbDir(tarDir,codei,intDir):
    if codei == 'T':
        sylbDir = tarDir
    elif codei == 'D':
        if tarDir == '30L':
            sylbDir = '30R'
        elif tarDir == '30R':
            sylbDir = '30L'
        else:
            raise ValueError
    elif codei == 'I':
        if intDir == 'cont':
            if tarDir == '30L':
                sylbDir = '90R'
            elif tarDir == '30R':
                sylbDir = '90L'
            else:
                raise ValueError
        elif intDir == 'ips':
            if tarDir == '30L':
                sylbDir = '90L'
            elif tarDir == '30R':
                sylbDir = '90R'
            else:
                raise ValueError
        else:
            raise ValueError
    return sylbDir


def test_getTriggerCode():
    spaCond_pool = ['HRTF','ITD','ILD']
    intCond_pool = ['uninterrupted','interrupted']
    tarDir_pool = ['30L','30R']

    for spaCond in spaCond_pool:
        for intCond in intCond_pool:
            for tarDir in tarDir_pool:
                code = getTriggerCode(spaCond,intCond,tarDir)
                print(spaCond,intCond,tarDir,code)
    return code 
