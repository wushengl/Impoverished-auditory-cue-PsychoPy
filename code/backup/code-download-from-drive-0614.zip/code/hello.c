#include<stdio.h>
 
int main()
{
 
    printf("hello vs build tools.\n");
    printf("press any key to exit.\n");
    getchar();
    return 0;
 
}